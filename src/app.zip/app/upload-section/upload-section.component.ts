import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-upload-section',
  templateUrl: './upload-section.component.html',
  styleUrls: ['./upload-section.component.scss']
})
export class UploadSectionComponent implements OnInit {
  @Input() selectedAccountNumber: string = ''; 
  @Output() back = new EventEmitter<void>();
  files: File[] = [];
  uploadedFiles: { accountNumber: string; fileName: string; status: string }[] = [];

  constructor() {}

  ngOnInit(): void {
    if (this.selectedAccountNumber) {
      console.log('Received selected account number:', this.selectedAccountNumber);
    } else {
      console.log('No account number received.');
    }
  }
  

  onSelect(event: any) {
    const selectedFiles: File[] = event.addedFiles;

    if (selectedFiles && selectedFiles.length > 0) {
      for (const file of selectedFiles) {
        if (file.type === 'application/pdf') {
          this.files.push(file); // Add file to the array
        } else {
          alert('Only PDF files are accepted.');
        }
      }
    }

    // Debugging log
    console.log('Files selected:', this.files);
  }

  onRemove(file: File) {
    this.files.splice(this.files.indexOf(file), 1);

    // Debugging log
    console.log('Files after removal:', this.files);
  }

  backToEnquire() {
    this.back.emit();
  }

  onUpload() {
    if (this.files.length === 0 || !this.selectedAccountNumber) {
      return; 
    }

    // Simulate a successful upload with a dummy response
    setTimeout(() => {
      this.files.forEach(file => {
        this.uploadedFiles.push({
          accountNumber: this.selectedAccountNumber,
          fileName: file.name,
          status: 'Successfully Uploaded'
        });
      });

      // Clear the files after upload
      this.files = [];

      // Debugging log
      console.log('Uploaded files:', this.uploadedFiles);
    }, 1000); // Simulate a short delay for the "upload"
  }
}
