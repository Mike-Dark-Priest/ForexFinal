import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generic-dashboard',
  templateUrl: './generic-dashboard.component.html',
  styleUrls: ['./generic-dashboard.component.scss']
})
export class GenericDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
