import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  userPermissions!: any;
  userPermissionsIncludes!: any;
  userEbhubRoles!: any;
  digitalPortalSpecialRoles!: any;
  loanGenerationDeductatSource!: any;

  constructor() { }

  ngOnInit(): void {
    // //get the user data to be able to assign permissions
    // const userdata = JSON.parse(localStorage.getItem('user_data') || "");  
    // this.userPermissions = userdata.data.user.permissions;
    // this.userPermissionsIncludes = userdata.data.user

    // const userroles = JSON.parse(localStorage.getItem('ebhubspecialroles') || "");
    // this.userEbhubRoles = userroles

    // //assign user roles from the database for the application
    // this.digitalPortalSpecialRoles = JSON.parse(localStorage.getItem('digitalportalspecialroles') || '');
    // this.loanGenerationDeductatSource = this.digitalPortalSpecialRoles.LOAN_GENERATION
  }

}
